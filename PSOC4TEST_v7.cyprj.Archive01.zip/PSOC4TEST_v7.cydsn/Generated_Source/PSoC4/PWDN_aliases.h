/*******************************************************************************
* File Name: PWDN.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_PWDN_ALIASES_H) /* Pins PWDN_ALIASES_H */
#define CY_PINS_PWDN_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define PWDN_0			(PWDN__0__PC)
#define PWDN_0_PS		(PWDN__0__PS)
#define PWDN_0_PC		(PWDN__0__PC)
#define PWDN_0_DR		(PWDN__0__DR)
#define PWDN_0_SHIFT	(PWDN__0__SHIFT)
#define PWDN_0_INTR	((uint16)((uint16)0x0003u << (PWDN__0__SHIFT*2u)))

#define PWDN_INTR_ALL	 ((uint16)(PWDN_0_INTR))


#endif /* End Pins PWDN_ALIASES_H */


/* [] END OF FILE */
